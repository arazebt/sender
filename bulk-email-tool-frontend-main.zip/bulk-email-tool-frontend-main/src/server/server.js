export const server = {
    api: 'http://localhost:3005/api'
}